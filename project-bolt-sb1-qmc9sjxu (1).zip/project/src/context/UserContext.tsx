import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserProfile, TestResults } from '../types';

interface UserContextProps {
  userProfile: UserProfile | null;
  userResults: TestResults | null;
  setUserProfile: (profile: UserProfile) => void;
  setUserResults: (results: TestResults) => void;
}

const UserContext = createContext<UserContextProps | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userResults, setUserResults] = useState<TestResults | null>(null);
  
  return (
    <UserContext.Provider
      value={{
        userProfile,
        userResults,
        setUserProfile,
        setUserResults
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextProps => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};