export interface UserProfile {
  id?: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface TestResults {
  iqScore: number;
  completionTime: number;
  correctAnswers: number;
  totalQuestions: number;
  strengths: string[];
  weaknesses: string[];
}

export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: string;
  difficulty: number;
  category: string;
  image?: string;
}

export interface TestState {
  currentQuestionIndex: number;
  answers: string[];
  timeRemaining: number;
  isStarted: boolean;
  isPaused: boolean;
  narrativeShown: boolean;
}