import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Gauge, Trophy, Users, ChevronRight } from 'lucide-react';
import HeroSection from '../components/home/HeroSection';
import FeatureCard from '../components/home/FeatureCard';
import TestimonialCard from '../components/home/TestimonialCard';

const testimonials = [
  {
    id: 1,
    name: 'Sarah K.',
    role: 'Software Engineer',
    content: 'Mind\'s Enigma helped me discover cognitive strengths I never knew I had. The horror theme made the experience unforgettable!',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: 2,
    name: 'Michael R.',
    role: 'Psychology Student',
    content: 'As a psychology student, I was impressed by the depth of analysis. The eerie atmosphere actually helped me focus!',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: 3,
    name: 'Elena J.',
    role: 'Marketing Director',
    content: 'The adaptive questions challenged me in ways other IQ tests never did. Facing your cognitive fears is strangely empowering.',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150'
  }
];

const features = [
  {
    id: 1,
    title: 'Adaptive Intelligence',
    description: 'Our questions adapt to your cognitive strengths and weaknesses in real-time, pushing your mind to its limits.',
    icon: <Brain className="h-8 w-8 text-cyan-400" />
  },
  {
    id: 2,
    title: 'Performance Metrics',
    description: 'Receive detailed analytics on your cognitive performance with visual representations of your mental capabilities.',
    icon: <Gauge className="h-8 w-8 text-cyan-400" />
  },
  {
    id: 3,
    title: 'Global Ranking',
    description: 'See how your intelligence compares to others worldwide with our comprehensive ranking system.',
    icon: <Trophy className="h-8 w-8 text-cyan-400" />
  },
  {
    id: 4,
    title: 'Community Insights',
    description: 'Gain access to a community of like-minded individuals and compare your cognitive patterns.',
    icon: <Users className="h-8 w-8 text-cyan-400" />
  }
];

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleStartTest = () => {
    navigate('/test');
  };

  return (
    <div className="flex flex-col w-full">
      <HeroSection onStartTest={handleStartTest} />
      
      {/* Features Section */}
      <section className="py-16 px-4 max-w-7xl mx-auto w-full">
        <h2 className="text-3xl font-bold text-center mb-4">Unravel Your Mind's Potential</h2>
        <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
          Discover the darkest corners of your intelligence with our horror-themed cognitive assessment.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map(feature => (
            <FeatureCard 
              key={feature.id}
              title={feature.title}
              description={feature.description}
              icon={feature.icon}
            />
          ))}
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-16 px-4 bg-gray-900">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-4">Testimonials from the Brave</h2>
          <p className="text-gray-400 text-center max-w-2xl mx-auto mb-12">
            Hear from those who have faced their cognitive fears and emerged enlightened.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map(testimonial => (
              <TestimonialCard 
                key={testimonial.id}
                name={testimonial.name}
                role={testimonial.role}
                content={testimonial.content}
                avatar={testimonial.avatar}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Challenge Your Mind?</h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-8">
            Embark on a journey through the labyrinth of your own intelligence. The darkness awaits.
          </p>
          <button 
            onClick={handleStartTest}
            className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium flex items-center mx-auto transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.5)]"
          >
            Begin Your Test
            <ChevronRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;