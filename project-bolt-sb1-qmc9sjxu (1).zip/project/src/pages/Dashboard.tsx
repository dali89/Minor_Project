import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Calendar, BarChart, Clock, ChevronRight, MailOpen } from 'lucide-react';
import { useUser } from '../context/UserContext';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { userProfile, userResults } = useUser();
  const [activeTab, setActiveTab] = useState('overview');
  
  const handleStartTest = () => {
    navigate('/test');
  };
  
  const handleViewResults = () => {
    navigate('/results');
  };
  
  return (
    <div className="min-h-screen bg-gray-950 pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="w-full md:w-64 flex-shrink-0">
            <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg sticky top-24">
              <div className="flex flex-col items-center mb-6">
                <div className="w-20 h-20 bg-gray-800 rounded-full mb-4 flex items-center justify-center text-gray-600 overflow-hidden border-2 border-cyan-500">
                  {userProfile?.avatar ? (
                    <img 
                      src={userProfile.avatar} 
                      alt={userProfile.name} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-10 w-10" />
                  )}
                </div>
                <h2 className="text-lg font-semibold">
                  {userProfile?.name || 'Guest User'}
                </h2>
                <p className="text-sm text-gray-400">
                  {userProfile?.email || 'Sign in to save your progress'}
                </p>
              </div>
              
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    activeTab === 'overview'
                      ? 'bg-gray-800 text-cyan-400'
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                  }`}
                >
                  <BarChart className="mr-3 h-4 w-4" />
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('tests')}
                  className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    activeTab === 'tests'
                      ? 'bg-gray-800 text-cyan-400'
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                  }`}
                >
                  <Calendar className="mr-3 h-4 w-4" />
                  Test History
                </button>
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    activeTab === 'profile'
                      ? 'bg-gray-800 text-cyan-400'
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                  }`}
                >
                  <User className="mr-3 h-4 w-4" />
                  Profile
                </button>
              </nav>
              
              <div className="mt-6 pt-6 border-t border-gray-800">
                <button
                  onClick={handleStartTest}
                  className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-2 px-4 rounded-md font-medium transition-all duration-300 shadow-[0_0_10px_rgba(0,240,255,0.3)] flex items-center justify-center"
                >
                  Start New Test
                  <ChevronRight className="ml-2 h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg">
                  <h2 className="text-xl font-bold mb-4">Dashboard Overview</h2>
                  
                  {userResults ? (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                        <div className="flex items-center">
                          <div className="bg-cyan-900/40 p-3 rounded-full mr-4">
                            <BarChart className="h-6 w-6 text-cyan-400" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-400">IQ Score</p>
                            <p className="text-2xl font-bold">{userResults.iqScore}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                        <div className="flex items-center">
                          <div className="bg-purple-900/40 p-3 rounded-full mr-4">
                            <Clock className="h-6 w-6 text-purple-400" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-400">Last Test</p>
                            <p className="text-2xl font-bold">Today</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                        <div className="flex items-center">
                          <div className="bg-blue-900/40 p-3 rounded-full mr-4">
                            <Calendar className="h-6 w-6 text-blue-400" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-400">Tests Taken</p>
                            <p className="text-2xl font-bold">1</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-800 rounded-lg p-6 text-center">
                      <p className="text-gray-400 mb-4">You haven't taken any tests yet.</p>
                      <button
                        onClick={handleStartTest}
                        className="bg-cyan-600 hover:bg-cyan-700 text-white py-2 px-6 rounded-md font-medium transition-all duration-300"
                      >
                        Take Your First Test
                      </button>
                    </div>
                  )}
                </div>
                
                {userResults && (
                  <>
                    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg">
                      <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold">Recent Results</h2>
                        <button
                          onClick={handleViewResults}
                          className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
                        >
                          View Details
                        </button>
                      </div>
                      
                      <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                          <div>
                            <h3 className="font-semibold">Standard IQ Assessment</h3>
                            <p className="text-sm text-gray-400">Completed today</p>
                          </div>
                          <div className="mt-2 sm:mt-0 flex items-center">
                            <div className="bg-gray-700 h-8 w-8 rounded-full flex items-center justify-center mr-2">
                              <span className="text-sm font-bold">{userResults.iqScore}</span>
                            </div>
                            <span className="text-sm text-gray-400">IQ Score</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg">
                      <h2 className="text-xl font-bold mb-4">Recommended Tests</h2>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-cyan-900 transition-all duration-300">
                          <h3 className="font-semibold mb-2">Pattern Recognition</h3>
                          <p className="text-sm text-gray-400 mb-3">
                            A focused test on your ability to identify patterns and sequences.
                          </p>
                          <button className="text-sm text-cyan-400 flex items-center">
                            Take test <ChevronRight className="ml-1 h-4 w-4" />
                          </button>
                        </div>
                        
                        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-cyan-900 transition-all duration-300">
                          <h3 className="font-semibold mb-2">Spatial Reasoning</h3>
                          <p className="text-sm text-gray-400 mb-3">
                            Improve your weaker areas with this specialized spatial reasoning test.
                          </p>
                          <button className="text-sm text-cyan-400 flex items-center">
                            Take test <ChevronRight className="ml-1 h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                
                <div className="bg-gradient-to-r from-gray-900 to-cyan-900/30 rounded-lg p-6 border border-gray-800 shadow-lg">
                  <div className="flex items-start space-x-4">
                    <div className="bg-cyan-900/40 p-3 rounded-full">
                      <MailOpen className="h-6 w-6 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Stay Updated</h3>
                      <p className="text-gray-300 mb-4">
                        Subscribe to our newsletter for the latest insights on cognitive science and new test features.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="email"
                          placeholder="Enter your email"
                          className="bg-gray-800 border border-gray-700 text-gray-300 px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500 sm:flex-1"
                        />
                        <button className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
                          Subscribe
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'tests' && (
              <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg">
                <h2 className="text-xl font-bold mb-6">Test History</h2>
                
                {userResults ? (
                  <div className="space-y-4">
                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                        <div>
                          <h3 className="font-semibold">Standard IQ Assessment</h3>
                          <p className="text-sm text-gray-400">Completed today</p>
                        </div>
                        <div className="mt-2 sm:mt-0 flex items-center space-x-4">
                          <div>
                            <span className="text-sm text-gray-400">Score:</span>
                            <span className="ml-1 font-bold">{userResults.iqScore}</span>
                          </div>
                          <button
                            onClick={handleViewResults}
                            className="text-cyan-400 hover:text-cyan-300 transition-colors text-sm"
                          >
                            View Results
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-center text-gray-400 py-4">No additional test history available.</p>
                  </div>
                ) : (
                  <div className="bg-gray-800 rounded-lg p-6 text-center">
                    <p className="text-gray-400 mb-4">You haven't taken any tests yet.</p>
                    <button
                      onClick={handleStartTest}
                      className="bg-cyan-600 hover:bg-cyan-700 text-white py-2 px-6 rounded-md font-medium transition-all duration-300"
                    >
                      Take Your First Test
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'profile' && (
              <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg">
                <h2 className="text-xl font-bold mb-6">Profile Settings</h2>
                
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-6 items-start">
                    <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center text-gray-600 overflow-hidden border-2 border-cyan-500">
                      {userProfile?.avatar ? (
                        <img 
                          src={userProfile.avatar} 
                          alt={userProfile.name} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="h-12 w-12" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-4">Profile Photo</h3>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <button className="bg-gray-800 text-gray-300 px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                          Upload New Photo
                        </button>
                        <button className="bg-gray-800 text-gray-300 px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-800 pt-6">
                    <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          value={userProfile?.name || ''}
                          className="w-full bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          value={userProfile?.email || ''}
                          className="w-full bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">
                          Age Group
                        </label>
                        <select className="w-full bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-white">
                          <option>Select age group</option>
                          <option>18-24</option>
                          <option>25-34</option>
                          <option>35-44</option>
                          <option>45-54</option>
                          <option>55+</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-1">
                          Education Level
                        </label>
                        <select className="w-full bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-white">
                          <option>Select education level</option>
                          <option>High School</option>
                          <option>Bachelor's Degree</option>
                          <option>Master's Degree</option>
                          <option>Doctorate</option>
                          <option>Other</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-800 pt-6">
                    <h3 className="text-lg font-semibold mb-4">Preferences</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <input
                          id="darkTheme"
                          name="darkTheme"
                          type="checkbox"
                          className="h-4 w-4 rounded border-gray-700 text-cyan-600 focus:ring-cyan-500 bg-gray-800"
                          defaultChecked
                        />
                        <label htmlFor="darkTheme" className="ml-2 block text-sm text-gray-300">
                          Enable dark theme (recommended for horror experience)
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="notifications"
                          name="notifications"
                          type="checkbox"
                          className="h-4 w-4 rounded border-gray-700 text-cyan-600 focus:ring-cyan-500 bg-gray-800"
                        />
                        <label htmlFor="notifications" className="ml-2 block text-sm text-gray-300">
                          Receive email notifications about new tests
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="soundEffects"
                          name="soundEffects"
                          type="checkbox"
                          className="h-4 w-4 rounded border-gray-700 text-cyan-600 focus:ring-cyan-500 bg-gray-800"
                        />
                        <label htmlFor="soundEffects" className="ml-2 block text-sm text-gray-300">
                          Enable horror sound effects during tests
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-800 pt-6 flex justify-end">
                    <button className="bg-cyan-600 hover:bg-cyan-700 text-white py-2 px-6 rounded-md font-medium transition-all duration-300 shadow-[0_0_10px_rgba(0,240,255,0.3)]">
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;