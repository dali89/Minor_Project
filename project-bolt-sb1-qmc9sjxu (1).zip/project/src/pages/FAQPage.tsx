import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: "What makes Mind's Enigma different from other IQ tests?",
    answer: "Mind's Enigma combines scientifically validated cognitive assessment with an immersive horror theme, creating a unique testing environment that challenges your mind in new ways. Our adaptive difficulty system ensures a personalized experience that accurately measures your cognitive abilities."
  },
  {
    question: "How long does the test take to complete?",
    answer: "The standard IQ assessment consists of 20 questions and takes approximately 30 minutes to complete. This time limit is carefully calibrated to measure both your problem-solving abilities and performance under pressure."
  },
  {
    question: "Is the horror theme too intense?",
    answer: "Our horror elements are psychological rather than graphic, focusing on creating an atmosphere of cognitive tension. The intensity is carefully balanced to enhance focus without causing undue stress. However, users can adjust or disable certain thematic elements in their settings."
  },
  {
    question: "How accurate are the test results?",
    answer: "Our IQ assessment is based on established psychometric principles and has been validated through extensive research. The test adapts to your performance in real-time, ensuring accurate measurement of your cognitive abilities across multiple domains."
  },
  {
    question: "Can I practice before taking the actual test?",
    answer: "Yes, we offer a free practice mode that familiarizes you with the question types and horror elements without affecting your official score. This helps ensure you're comfortable with the format before taking the full assessment."
  },
  {
    question: "How often can I take the test?",
    answer: "We recommend waiting at least 30 days between full assessments to ensure the most accurate results. However, you can access practice questions and specific cognitive training exercises at any time."
  },
  {
    question: "Are my results private?",
    answer: "Yes, your privacy is paramount. All test results and personal information are encrypted and stored securely. You have full control over what information you share and can manage your privacy settings in your dashboard."
  },
  {
    question: "What do the results tell me?",
    answer: "Your results provide a comprehensive analysis of your cognitive abilities, including your IQ score, percentile ranking, and detailed breakdown of your strengths and weaknesses across different cognitive domains. We also provide personalized recommendations for improvement."
  },
  {
    question: "Is there scientific research behind the test?",
    answer: "Yes, Mind's Enigma is built on established psychological research and modern psychometric principles. Our team of psychologists and researchers continuously updates our methodology based on the latest scientific findings in cognitive assessment."
  },
  {
    question: "Can I use my results for academic or professional purposes?",
    answer: "While our test provides valuable insights into your cognitive abilities, we recommend consulting with specific institutions or organizations about their accepted IQ assessment requirements, as these may vary."
  }
];

const FAQPage: React.FC = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev =>
      prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <div className="min-h-screen bg-gray-950 pt-20 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-400">
            Find answers to common questions about Mind's Enigma
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-lg border border-gray-800 overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-800 transition-colors"
                onClick={() => toggleItem(index)}
              >
                <span className="font-medium">{faq.question}</span>
                {openItems.includes(index) ? (
                  <ChevronUp className="h-5 w-5 text-cyan-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-cyan-400" />
                )}
              </button>
              
              {openItems.includes(index) && (
                <div className="px-6 py-4 border-t border-gray-800 bg-gray-900/50">
                  <p className="text-gray-400">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Section */}
        <div className="mt-12 bg-gradient-to-r from-gray-900 to-cyan-900/30 rounded-lg p-8 border border-gray-800 text-center">
          <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-gray-400 mb-6">
            Our support team is here to help you with any additional questions or concerns.
          </p>
          <a
            href="mailto:support@mindsenigma.com"
            className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium inline-flex transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
          >
            Contact Support
          </a>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;