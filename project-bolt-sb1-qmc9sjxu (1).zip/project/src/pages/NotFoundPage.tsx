import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        <h1 className="text-7xl font-bold text-cyan-400 mb-4">404</h1>
        <h2 className="text-2xl font-semibold mb-6">Lost in the Mental Abyss</h2>
        <p className="text-gray-400 mb-8">
          This path leads nowhere. Your mind has wandered into uncharted territory.
          Return to known cognitive regions.
        </p>
        <button
          onClick={() => navigate('/')}
          className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-6 rounded-lg font-medium inline-flex items-center transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
        >
          <Home className="mr-2 h-5 w-5" />
          Return Home
        </button>
      </div>
    </div>
  );
};

export default NotFoundPage;