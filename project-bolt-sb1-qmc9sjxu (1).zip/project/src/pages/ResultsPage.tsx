import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Share2, Download, Brain, ArrowRight } from 'lucide-react';
import { useUser } from '../context/UserContext';
import ScoreGauge from '../components/results/ScoreGauge';
import StrengthWeaknessCard from '../components/results/StrengthWeaknessCard';
import PercentileChart from '../components/results/PercentileChart';

const ResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const { userResults } = useUser();
  const [showShareOptions, setShowShareOptions] = useState(false);
  
  // Redirect if no results
  if (!userResults) {
    navigate('/');
    return null;
  }
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins} minutes ${secs} seconds`;
  };
  
  const handleTakeNewTest = () => {
    navigate('/test');
  };
  
  const handleShare = () => {
    setShowShareOptions(!showShareOptions);
  };
  
  const handleDownloadResults = () => {
    // Implementation would go here in a real application
    alert('Download functionality would be implemented here');
  };
  
  return (
    <div className="min-h-screen bg-gray-950 pt-20 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Your Cognitive Assessment Results</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            The shadows of your mind have been measured. Here's what we found lurking in the darkness.
          </p>
        </div>
        
        {/* IQ Score Section */}
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg mb-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-4">Your IQ Score</h2>
            <div className="flex justify-center">
              <ScoreGauge score={userResults.iqScore} />
            </div>
            <p className="text-gray-400 mt-4">
              Your score places you in the <span className="text-cyan-400 font-semibold">top {100 - Math.round((userResults.iqScore - 80) / 60 * 100)}%</span> of test takers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center mb-2">
                <div className="w-3 h-3 rounded-full bg-cyan-500 mr-2"></div>
                <h3 className="font-semibold">Test Performance</h3>
              </div>
              <p className="text-sm text-gray-400">
                You correctly answered <span className="text-white font-medium">{userResults.correctAnswers} out of {userResults.totalQuestions}</span> questions.
              </p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center mb-2">
                <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
                <h3 className="font-semibold">Completion Time</h3>
              </div>
              <p className="text-sm text-gray-400">
                You completed the test in <span className="text-white font-medium">{formatTime(userResults.completionTime)}</span>.
              </p>
            </div>
          </div>
        </div>
        
        {/* Percentile Ranking */}
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg mb-8">
          <h2 className="text-2xl font-bold mb-6">Percentile Ranking</h2>
          <PercentileChart iqScore={userResults.iqScore} />
          <div className="mt-4 text-center text-sm text-gray-400">
            Your score of <span className="text-white font-medium">{userResults.iqScore}</span> places you in the cognitive elite.
          </div>
        </div>
        
        {/* Strengths and Weaknesses */}
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg mb-8">
          <h2 className="text-2xl font-bold mb-6">Cognitive Profile</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <StrengthWeaknessCard
              title="Cognitive Strengths"
              items={userResults.strengths}
              type="strength"
            />
            <StrengthWeaknessCard
              title="Areas for Improvement"
              items={userResults.weaknesses}
              type="weakness"
            />
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex flex-col sm:flex-row justify-center gap-4 mt-12">
          <button
            onClick={handleTakeNewTest}
            className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium flex items-center justify-center transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
          >
            <Brain className="mr-2 h-5 w-5" />
            Take Another Test
          </button>
          
          <div className="relative">
            <button
              onClick={handleShare}
              className="bg-gray-800 hover:bg-gray-700 text-white py-3 px-8 rounded-lg font-medium flex items-center justify-center transition-all duration-300"
            >
              <Share2 className="mr-2 h-5 w-5" />
              Share Results
            </button>
            
            {showShareOptions && (
              <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-gray-800 ring-1 ring-black ring-opacity-5 z-10">
                <div className="py-1" role="menu" aria-orientation="vertical">
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                    role="menuitem"
                  >
                    Facebook
                  </a>
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                    role="menuitem"
                  >
                    Twitter
                  </a>
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                    role="menuitem"
                  >
                    LinkedIn
                  </a>
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                    role="menuitem"
                  >
                    Copy Link
                  </a>
                </div>
              </div>
            )}
          </div>
          
          <button
            onClick={handleDownloadResults}
            className="bg-gray-800 hover:bg-gray-700 text-white py-3 px-8 rounded-lg font-medium flex items-center justify-center transition-all duration-300"
          >
            <Download className="mr-2 h-5 w-5" />
            Download Report
          </button>
        </div>
        
        {/* Next Steps */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">What's Next?</h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-8">
            Explore more ways to challenge your mind and expand your cognitive potential.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-gray-900 p-6 rounded-lg border border-gray-800 hover:border-cyan-900 transition-all duration-300">
              <h3 className="font-semibold text-lg mb-2">Specialized Tests</h3>
              <p className="text-gray-400 text-sm mb-4">
                Try our focused assessments targeting specific cognitive domains.
              </p>
              <a href="#" className="text-cyan-400 text-sm flex items-center">
                Explore tests <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
            
            <div className="bg-gray-900 p-6 rounded-lg border border-gray-800 hover:border-cyan-900 transition-all duration-300">
              <h3 className="font-semibold text-lg mb-2">Brain Training</h3>
              <p className="text-gray-400 text-sm mb-4">
                Enhance your cognitive abilities with our daily mental exercises.
              </p>
              <a href="#" className="text-cyan-400 text-sm flex items-center">
                Start training <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
            
            <div className="bg-gray-900 p-6 rounded-lg border border-gray-800 hover:border-cyan-900 transition-all duration-300">
              <h3 className="font-semibold text-lg mb-2">Advanced Analysis</h3>
              <p className="text-gray-400 text-sm mb-4">
                Get an in-depth evaluation of your cognitive profile from our experts.
              </p>
              <a href="#" className="text-cyan-400 text-sm flex items-center">
                Learn more <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;