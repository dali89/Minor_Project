import React from 'react';
import { Brain, Target, Users, Shield } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-950 pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About Mind's Enigma</h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Exploring the depths of human cognition through innovative psychological assessment
          </p>
        </div>

        {/* Mission Section */}
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg mb-12">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Our Mission</h2>
            <p className="text-gray-300 leading-relaxed mb-6">
              Mind's Enigma was founded with a singular purpose: to revolutionize cognitive assessment
              through an immersive, horror-themed experience that challenges conventional testing
              methods. We believe that by introducing elements of psychological tension, we can better
              measure true cognitive capabilities under varying conditions.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Our platform combines cutting-edge psychometric science with engaging narrative elements,
              creating a unique testing environment that pushes the boundaries of traditional IQ
              assessment while maintaining scientific validity and reliability.
            </p>
          </div>
        </div>

        {/* Core Values */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
            <div className="bg-cyan-900/40 p-3 rounded-full inline-block mb-4">
              <Brain className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Scientific Rigor</h3>
            <p className="text-gray-400">
              Our assessments are built on established psychological principles and validated through
              extensive research.
            </p>
          </div>

          <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
            <div className="bg-cyan-900/40 p-3 rounded-full inline-block mb-4">
              <Target className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Innovation</h3>
            <p className="text-gray-400">
              We continuously push boundaries to create unique, engaging testing experiences that
              challenge conventional methods.
            </p>
          </div>

          <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
            <div className="bg-cyan-900/40 p-3 rounded-full inline-block mb-4">
              <Users className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Accessibility</h3>
            <p className="text-gray-400">
              We strive to make cognitive assessment accessible to everyone, regardless of background
              or experience.
            </p>
          </div>

          <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
            <div className="bg-cyan-900/40 p-3 rounded-full inline-block mb-4">
              <Shield className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Privacy</h3>
            <p className="text-gray-400">
              We maintain the highest standards of data protection and user privacy in all our
              operations.
            </p>
          </div>
        </div>

        {/* Team Section */}
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg mb-12">
          <h2 className="text-2xl font-bold mb-8 text-center">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 border-2 border-cyan-500">
                <img
                  src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=300"
                  alt="Dr. James Wilson"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-lg font-semibold">Dr. James Wilson</h3>
              <p className="text-cyan-400">Chief Psychologist</p>
            </div>

            <div className="text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 border-2 border-cyan-500">
                <img
                  src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300"
                  alt="Dr. Sarah Chen"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-lg font-semibold">Dr. Sarah Chen</h3>
              <p className="text-cyan-400">Research Director</p>
            </div>

            <div className="text-center">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-4 border-2 border-cyan-500">
                <img
                  src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300"
                  alt="Mark Thompson"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-lg font-semibold">Mark Thompson</h3>
              <p className="text-cyan-400">Tech Lead</p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-gradient-to-r from-gray-900 to-cyan-900/30 rounded-lg p-8 border border-gray-800 shadow-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Get in Touch</h2>
            <p className="text-gray-400 mb-6">
              Have questions about our platform or interested in collaboration opportunities?
            </p>
            <a
              href="mailto:contact@mindsenigma.com"
              className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium inline-flex items-center transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;