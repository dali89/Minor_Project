import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, AlertCircle } from 'lucide-react';
import QuestionCard from '../components/test/QuestionCard';
import ProgressBar from '../components/test/ProgressBar';
import HorrorNarrative from '../components/test/HorrorNarrative';
import { useUser } from '../context/UserContext';
import { Question, TestState } from '../types';
import { questions } from '../data/questions';

const TEST_DURATION = 30 * 60; // 30 minutes in seconds

const TestPage: React.FC = () => {
  const navigate = useNavigate();
  const { setUserResults } = useUser();
  
  const [testState, setTestState] = useState<TestState>({
    currentQuestionIndex: 0,
    answers: [],
    timeRemaining: TEST_DURATION,
    isStarted: false,
    isPaused: false,
    narrativeShown: false
  });
  
  const [currentQuestion, setCurrentQuestion] = useState<Question>(questions[0]);
  
  // Start test effect
  useEffect(() => {
    if (testState.isStarted && !testState.isPaused) {
      const timer = setInterval(() => {
        setTestState(prev => {
          const newTimeRemaining = prev.timeRemaining - 1;
          
          // Auto-submit if time runs out
          if (newTimeRemaining <= 0) {
            clearInterval(timer);
            handleSubmitTest();
            return { ...prev, timeRemaining: 0 };
          }
          
          return { ...prev, timeRemaining: newTimeRemaining };
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [testState.isStarted, testState.isPaused]);
  
  // Show narrative between questions
  useEffect(() => {
    if (testState.isStarted && 
        testState.currentQuestionIndex > 0 && 
        testState.currentQuestionIndex % 5 === 0 && 
        !testState.narrativeShown) {
      setTestState(prev => ({ ...prev, isPaused: true, narrativeShown: true }));
    }
  }, [testState.currentQuestionIndex, testState.isStarted, testState.narrativeShown]);
  
  // Update current question when index changes
  useEffect(() => {
    setCurrentQuestion(questions[testState.currentQuestionIndex]);
  }, [testState.currentQuestionIndex]);
  
  const handleStartTest = () => {
    setTestState(prev => ({ ...prev, isStarted: true }));
  };
  
  const handleAnswer = (answer: string) => {
    setTestState(prev => {
      const updatedAnswers = [...prev.answers];
      updatedAnswers[prev.currentQuestionIndex] = answer;
      
      // Move to next question if not the last one
      if (prev.currentQuestionIndex < questions.length - 1) {
        return {
          ...prev,
          answers: updatedAnswers,
          currentQuestionIndex: prev.currentQuestionIndex + 1,
          narrativeShown: false
        };
      } 
      // Otherwise, prepare to submit the test
      else {
        return {
          ...prev,
          answers: updatedAnswers
        };
      }
    });
  };
  
  const handlePrevQuestion = () => {
    setTestState(prev => ({
      ...prev,
      currentQuestionIndex: Math.max(0, prev.currentQuestionIndex - 1)
    }));
  };
  
  const handleContinueNarrative = () => {
    setTestState(prev => ({ ...prev, isPaused: false, narrativeShown: false }));
  };
  
  const handleSubmitTest = () => {
    // Calculate results based on answers
    const score = testState.answers.reduce((total, answer, index) => {
      return total + (answer === questions[index].correctAnswer ? 1 : 0);
    }, 0);
    
    const iqScore = 80 + Math.round((score / questions.length) * 60);
    
    // Save results to context for the results page
    setUserResults({
      iqScore,
      completionTime: TEST_DURATION - testState.timeRemaining,
      correctAnswers: score,
      totalQuestions: questions.length,
      strengths: ['Pattern Recognition', 'Logical Reasoning'],
      weaknesses: ['Spatial Awareness', 'Verbal Reasoning']
    });
    
    // Navigate to results page
    navigate('/results');
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Calculate progress percentage
  const progress = (testState.currentQuestionIndex / questions.length) * 100;
  
  return (
    <div className="min-h-screen bg-gray-950 pt-16">
      {!testState.isStarted ? (
        // Start screen
        <div className="max-w-4xl mx-auto py-16 px-4">
          <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg">
            <h1 className="text-3xl font-bold text-center mb-8">Mind's Enigma: IQ Assessment</h1>
            
            <div className="mb-8 bg-gray-800 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4 text-cyan-400">Test Instructions</h2>
              <ul className="space-y-2 text-gray-300">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>This test contains 20 questions of increasing difficulty.</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>You have 30 minutes to complete the assessment.</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Each question has only one correct answer.</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>The test adapts to your performance as you progress.</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Horror narrative elements will appear throughout the test.</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gray-800 p-6 rounded-lg mb-8">
              <div className="flex items-center">
                <AlertCircle className="h-6 w-6 text-yellow-500 mr-2" />
                <h2 className="text-xl font-semibold text-yellow-500">Warning</h2>
              </div>
              <p className="mt-2 text-gray-300">
                This test contains horror themes and imagery. The narrative may include
                disturbing scenarios that adapt based on your cognitive performance.
                Proceed at your own risk.
              </p>
            </div>
            
            <div className="text-center">
              <button
                onClick={handleStartTest}
                className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
              >
                Begin Assessment
              </button>
            </div>
          </div>
        </div>
      ) : testState.narrativeShown ? (
        // Narrative screen between question sets
        <div className="max-w-4xl mx-auto py-16 px-4">
          <HorrorNarrative 
            questionIndex={testState.currentQuestionIndex} 
            onContinue={handleContinueNarrative} 
          />
        </div>
      ) : (
        // Test screen
        <div className="max-w-4xl mx-auto py-8 px-4">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <span className="text-lg font-medium mr-2">
                Question {testState.currentQuestionIndex + 1}/{questions.length}
              </span>
            </div>
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-cyan-400 mr-2" />
              <span className={`font-mono text-lg ${
                testState.timeRemaining < 300 ? 'text-red-500' : 'text-white'
              }`}>
                {formatTime(testState.timeRemaining)}
              </span>
            </div>
          </div>
          
          <ProgressBar progress={progress} />
          
          <div className="mt-8">
            <QuestionCard 
              question={currentQuestion}
              questionNumber={testState.currentQuestionIndex + 1}
              onAnswer={handleAnswer}
              selectedAnswer={testState.answers[testState.currentQuestionIndex]}
            />
          </div>
          
          <div className="mt-8 flex justify-between">
            <button
              onClick={handlePrevQuestion}
              disabled={testState.currentQuestionIndex === 0}
              className={`px-4 py-2 rounded ${
                testState.currentQuestionIndex === 0 
                  ? 'bg-gray-700 text-gray-500 cursor-not-allowed' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
            >
              Previous
            </button>
            
            {testState.currentQuestionIndex === questions.length - 1 && testState.answers[testState.currentQuestionIndex] && (
              <button
                onClick={handleSubmitTest}
                className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-[0_0_10px_rgba(0,240,255,0.3)]"
              >
                Submit Test
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default TestPage;