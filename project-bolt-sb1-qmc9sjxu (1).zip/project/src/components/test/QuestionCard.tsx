import React from 'react';
import { Question } from '../../types';

interface QuestionCardProps {
  question: Question;
  questionNumber: number;
  onAnswer: (answer: string) => void;
  selectedAnswer?: string;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ 
  question, 
  questionNumber, 
  onAnswer, 
  selectedAnswer 
}) => {
  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 shadow-lg animate-fade-in">
      <h3 className="text-xl font-semibold mb-4">
        <span className="text-cyan-400">#{questionNumber}</span> {question.text}
      </h3>
      
      {question.image && (
        <div className="mb-4 border border-gray-800 rounded-lg overflow-hidden">
          <img 
            src={question.image} 
            alt={`Question ${questionNumber}`} 
            className="w-full object-contain"
          />
        </div>
      )}
      
      <div className="space-y-3 mt-6">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => onAnswer(option)}
            className={`w-full text-left p-4 rounded-lg transition-all duration-200 ${
              selectedAnswer === option
                ? 'bg-cyan-900 border border-cyan-500 shadow-[0_0_10px_rgba(0,240,255,0.3)]'
                : 'bg-gray-800 border border-gray-700 hover:border-gray-600'
            }`}
          >
            <span className="font-medium">{String.fromCharCode(65 + index)}.</span> {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuestionCard;