import React from 'react';

interface HorrorNarrativeProps {
  questionIndex: number;
  onContinue: () => void;
}

const narratives = [
  {
    title: "The Labyrinth Deepens",
    content: "As you progress deeper into the mental labyrinth, the corridors twist in impossible ways. The shadows lengthen, reaching toward you with ink-black fingers. Your mind is being tested, bent into shapes it was never meant to take. Continue, and see what waits in the darkness."
  },
  {
    title: "Echoes of Thought",
    content: "The mental chambers echo with whispers of past test-takers. Their failed attempts leave cognitive residue on the walls of your mind. You feel their frustration seeping into your consciousness. The test knows your weaknesses now. It will use them against you."
  },
  {
    title: "The Observer",
    content: "Something watches from the corners of your mind's eye. It evaluates your performance with cold precision. It's been there all along, measuring your mental capacity, noting your errors. As your awareness of it grows, it retreats further into the shadows of your subconscious."
  },
  {
    title: "Final Threshold",
    content: "The final threshold approaches. Few minds have traversed this far and returned intact. The questions will peel back layers of your cognitive defenses, exposing the raw neural pathways beneath. What you discover about yourself may change you forever."
  }
];

const HorrorNarrative: React.FC<HorrorNarrativeProps> = ({ questionIndex, onContinue }) => {
  const narrativeIndex = Math.min(Math.floor(questionIndex / 5) - 1, narratives.length - 1);
  const narrative = narratives[narrativeIndex];
  
  return (
    <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 shadow-lg animate-fade-in max-w-3xl mx-auto">
      <div className="mb-6 p-px bg-gradient-to-r from-cyan-500 to-blue-600"></div>
      
      <h2 className="text-3xl font-bold mb-6 text-cyan-400">{narrative.title}</h2>
      
      <p className="text-gray-300 text-lg leading-relaxed mb-8">
        {narrative.content}
      </p>
      
      <div className="flex justify-center">
        <button
          onClick={onContinue}
          className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]"
        >
          Continue the Test
        </button>
      </div>
      
      <div className="mt-10 text-center opacity-70">
        <p className="text-sm text-gray-500">
          The mind's enigma grows deeper as you proceed...
        </p>
      </div>
    </div>
  );
};

export default HorrorNarrative;