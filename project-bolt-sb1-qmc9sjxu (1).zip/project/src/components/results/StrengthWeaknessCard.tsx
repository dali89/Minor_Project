import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface StrengthWeaknessCardProps {
  title: string;
  items: string[];
  type: 'strength' | 'weakness';
}

const StrengthWeaknessCard: React.FC<StrengthWeaknessCardProps> = ({ title, items, type }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <h3 className="text-xl font-semibold mb-4">{title}</h3>
      <ul className="space-y-4">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            {type === 'strength' ? (
              <CheckCircle className="h-5 w-5 text-cyan-500 mr-2 flex-shrink-0 mt-0.5" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-medium">{item}</p>
              <p className="text-sm text-gray-400 mt-1">
                {type === 'strength' 
                  ? `You demonstrated exceptional abilities in ${item.toLowerCase()}.`
                  : `You may benefit from exercises that improve ${item.toLowerCase()}.`
                }
              </p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StrengthWeaknessCard;