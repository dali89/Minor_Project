import React, { useEffect, useState } from 'react';

interface ScoreGaugeProps {
  score: number;
}

const ScoreGauge: React.FC<ScoreGaugeProps> = ({ score }) => {
  const [animatedScore, setAnimatedScore] = useState(0);
  
  useEffect(() => {
    const duration = 2000; // 2 seconds
    const interval = 20; // Update every 20ms
    const steps = duration / interval;
    const increment = score / steps;
    let current = 0;
    let timer: number;
    
    const animate = () => {
      current += increment;
      if (current >= score) {
        current = score;
        clearInterval(timer);
      }
      setAnimatedScore(Math.floor(current));
    };
    
    timer = window.setInterval(animate, interval);
    return () => clearInterval(timer);
  }, [score]);
  
  // Calculate the gauge fill based on score (assuming IQ range of 80-140)
  const calculateFill = () => {
    const minScore = 80;
    const maxScore = 140;
    const percentage = ((score - minScore) / (maxScore - minScore)) * 100;
    return Math.min(Math.max(percentage, 0), 100);
  };
  
  const gaugePercentage = calculateFill();
  
  // Determine color based on score
  const getScoreColor = () => {
    if (score >= 130) return 'text-purple-500';
    if (score >= 120) return 'text-blue-500';
    if (score >= 110) return 'text-cyan-500';
    if (score >= 100) return 'text-green-500';
    if (score >= 90) return 'text-yellow-500';
    return 'text-red-500';
  };
  
  return (
    <div className="relative w-64 h-32">
      {/* Gauge background */}
      <div className="absolute w-full h-64 overflow-hidden" style={{ clipPath: 'polygon(0 100%, 100% 100%, 100% 0, 0 0)' }}>
        <div className="absolute w-full h-full rounded-full border-[16px] border-gray-800 top-0"></div>
      </div>
      
      {/* Gauge fill */}
      <div className="absolute w-full h-64 overflow-hidden" style={{ clipPath: 'polygon(0 100%, 100% 100%, 100% 0, 0 0)' }}>
        <div 
          className="absolute w-full h-full rounded-full border-[16px] border-gradient-animated top-0"
          style={{ 
            clip: `rect(0px, 256px, 256px, ${(100 - gaugePercentage) * 1.28}px)`,
            borderImage: 'linear-gradient(to right, #f00, #0ff, #00f) 1',
            transition: 'all 2s ease-out'
          }}
        ></div>
      </div>
      
      {/* Score display */}
      <div className="absolute inset-0 flex items-center justify-center mt-12">
        <div className="text-center">
          <div className={`text-4xl font-bold ${getScoreColor()}`}>
            {animatedScore}
          </div>
          <div className="text-xs text-gray-400 mt-1">IQ SCORE</div>
        </div>
      </div>
    </div>
  );
};

export default ScoreGauge;