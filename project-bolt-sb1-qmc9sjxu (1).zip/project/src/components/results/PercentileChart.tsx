import React, { useEffect, useRef } from 'react';

interface PercentileChartProps {
  iqScore: number;
}

const PercentileChart: React.FC<PercentileChartProps> = ({ iqScore }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas dimensions with device pixel ratio for sharpness
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    
    // Draw normal distribution curve
    const drawNormalDistribution = () => {
      const width = rect.width;
      const height = rect.height;
      const mean = 100; // IQ mean
      const stdDev = 15; // IQ standard deviation
      
      // Calculate normal distribution function
      const normalDist = (x: number) => {
        return (1 / (stdDev * Math.sqrt(2 * Math.PI))) * 
               Math.exp(-0.5 * Math.pow((x - mean) / stdDev, 2));
      };
      
      // Calculate the maximum value for scaling
      const maxVal = normalDist(mean);
      
      // Clear canvas
      ctx.clearRect(0, 0, width, height);
      
      // Draw x-axis
      ctx.beginPath();
      ctx.moveTo(0, height - 20);
      ctx.lineTo(width, height - 20);
      ctx.strokeStyle = '#4B5563'; // gray-600
      ctx.stroke();
      
      // Draw x-axis labels
      const labels = [70, 85, 100, 115, 130];
      const labelWidth = width / (labels.length - 1);
      
      labels.forEach((label, i) => {
        const x = i * labelWidth;
        ctx.fillStyle = '#9CA3AF'; // gray-400
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label.toString(), x, height - 5);
        
        // Draw tick mark
        ctx.beginPath();
        ctx.moveTo(x, height - 20);
        ctx.lineTo(x, height - 15);
        ctx.strokeStyle = '#4B5563'; // gray-600
        ctx.stroke();
      });
      
      // Draw curve
      ctx.beginPath();
      
      // Create gradient for the curve
      const gradient = ctx.createLinearGradient(0, 0, width, 0);
      gradient.addColorStop(0, 'rgba(239, 68, 68, 0.7)'); // red-500
      gradient.addColorStop(0.25, 'rgba(245, 158, 11, 0.7)'); // yellow-500
      gradient.addColorStop(0.5, 'rgba(16, 185, 129, 0.7)'); // green-500
      gradient.addColorStop(0.75, 'rgba(59, 130, 246, 0.7)'); // blue-500
      gradient.addColorStop(1, 'rgba(139, 92, 246, 0.7)'); // purple-500
      
      // Map IQ values to x-coordinates
      const minIQ = 55;
      const maxIQ = 145;
      const iqToX = (iq: number) => ((iq - minIQ) / (maxIQ - minIQ)) * width;
      
      // Draw the distribution curve
      for (let iq = minIQ; iq <= maxIQ; iq += 0.5) {
        const x = iqToX(iq);
        const y = height - 25 - (normalDist(iq) / maxVal) * (height - 60);
        
        if (iq === minIQ) {
          ctx.moveTo(x, height - 25);
          ctx.lineTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      
      // Complete the path to form a closed shape
      ctx.lineTo(iqToX(maxIQ), height - 25);
      ctx.closePath();
      
      // Fill with gradient
      ctx.fillStyle = gradient;
      ctx.fill();
      
      // Draw percentile marker for user's score
      const userX = iqToX(iqScore);
      const userY = height - 25 - (normalDist(iqScore) / maxVal) * (height - 60);
      
      // Draw vertical line
      ctx.beginPath();
      ctx.moveTo(userX, height - 20);
      ctx.lineTo(userX, userY - 10);
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Draw marker dot
      ctx.beginPath();
      ctx.arc(userX, userY - 10, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#00f0ff';
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Calculate percentile based on IQ
      // IQ follows a normal distribution, so we can use the cumulative distribution function
      const percentile = (1 - 0.5 * (1 + Math.erf((mean - iqScore) / (stdDev * Math.sqrt(2))))) * 100;
      
      // Display user's percentile
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 12px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(percentile)}th percentile`, userX, userY - 25);
    };
    
    // Initial draw
    drawNormalDistribution();
    
    // Redraw on window resize
    const handleResize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      drawNormalDistribution();
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [iqScore]);
  
  return (
    <div className="w-full">
      <canvas 
        ref={canvasRef} 
        style={{ width: '100%', height: '180px' }}
      ></canvas>
    </div>
  );
};

export default PercentileChart;