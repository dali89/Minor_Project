import React from 'react';

interface TestimonialCardProps {
  name: string;
  role: string;
  content: string;
  avatar: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ name, role, content, avatar }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 relative">
      <div className="absolute -top-5 left-6">
        <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-cyan-500">
          <img src={avatar} alt={name} className="w-full h-full object-cover" />
        </div>
      </div>
      <div className="pt-6">
        <p className="text-gray-300 mb-4">{content}</p>
        <div className="border-t border-gray-700 pt-4">
          <p className="font-semibold text-white">{name}</p>
          <p className="text-sm text-gray-400">{role}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;