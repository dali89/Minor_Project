import React from 'react';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, icon }) => {
  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800 hover:border-cyan-900 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-[0_5px_15px_rgba(0,240,255,0.15)]">
      <div className="bg-gray-800 rounded-full p-3 inline-block mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
};

export default FeatureCard;