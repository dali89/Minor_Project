import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface HeroSectionProps {
  onStartTest: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onStartTest }) => {
  const navigate = useNavigate();
  
  return (
    <section className="relative w-full bg-gray-950 overflow-hidden">
      {/* Animated background effect */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,240,255,0.15)_0,rgba(0,0,0,0)_70%)]"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 py-24 md:py-32 flex flex-col items-center">
        <div className="glitch-container mb-6">
          <h1 className="text-5xl md:text-7xl font-bold text-center text-white relative z-10">
            Know Your <span className="text-cyan-400">Potential</span>
          </h1>
          <div className="glitch-effect absolute inset-0 opacity-50"></div>
        </div>
        
        <p className="text-xl text-gray-300 text-center max-w-3xl mb-10">
          Delve into the depths of your mind with our horror-themed IQ assessment. 
          Face your cognitive fears and discover what lurks in the shadows of your intellect.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <button 
            onClick={onStartTest}
            className="bg-cyan-600 hover:bg-cyan-700 text-white py-3 px-8 rounded-lg font-medium flex items-center justify-center transition-all duration-300 shadow-[0_0_15px_rgba(0,240,255,0.5)]"
          >
            Start Your Test Now
            <ChevronRight className="ml-2 h-5 w-5" />
          </button>
          <button 
            onClick={() => navigate('/about')}
            className="bg-transparent hover:bg-gray-800 text-gray-300 border border-gray-700 py-3 px-8 rounded-lg font-medium transition-all duration-300"
          >
            Learn More
          </button>
        </div>
      </div>
      
      {/* Subtle floating elements */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-cyan-900/10 rounded-full blur-3xl animate-pulse-slow"></div>
      <div className="absolute bottom-1/3 right-1/4 w-48 h-48 bg-cyan-900/10 rounded-full blur-3xl animate-pulse-slow animation-delay-2000"></div>
    </section>
  );
};

export default HeroSection;