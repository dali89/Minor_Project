import { Question } from '../types';

export const questions: Question[] = [
  {
    id: 1,
    text: "Which number comes next in the sequence: 2, 4, 8, 16, ?",
    options: ["24", "32", "30", "64"],
    correctAnswer: "32",
    difficulty: 1,
    category: "Pattern Recognition"
  },
  {
    id: 2,
    text: "If SHADOW is coded as TIBEPX, how would HORROR be coded?",
    options: ["IPSVSB", "IPSSPS", "IPSUSQ", "IPSQPS"],
    correctAnswer: "IPSQPS",
    difficulty: 2,
    category: "Verbal Reasoning"
  },
  {
    id: 3,
    text: "Which shape completes the pattern?",
    image: "https://images.pexels.com/photos/6153354/pexels-photo-6153354.jpeg?auto=compress&cs=tinysrgb&w=600",
    options: ["Triangle", "Circle", "Square", "Hexagon"],
    correctAnswer: "Circle",
    difficulty: 2,
    category: "Spatial Reasoning"
  },
  {
    id: 4,
    text: "A doctor gives you 3 pills and tells you to take one every half hour. How long will the pills last?",
    options: ["30 minutes", "60 minutes", "90 minutes", "120 minutes"],
    correctAnswer: "60 minutes",
    difficulty: 1,
    category: "Logical Reasoning"
  },
  {
    id: 5,
    text: "Which word is the odd one out?",
    options: ["Dread", "Fear", "Terror", "Courage"],
    correctAnswer: "Courage",
    difficulty: 1,
    category: "Verbal Reasoning"
  },
  {
    id: 6,
    text: "If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
    options: ["5 minutes", "100 minutes", "20 minutes", "500 minutes"],
    correctAnswer: "5 minutes",
    difficulty: 3,
    category: "Logical Reasoning"
  },
  {
    id: 7,
    text: "Complete the analogy: Light is to Dark as _____ is to Death",
    options: ["Night", "Life", "Grave", "End"],
    correctAnswer: "Life",
    difficulty: 2,
    category: "Verbal Reasoning"
  },
  {
    id: 8,
    text: "Which number is the odd one out?",
    options: ["13", "23", "43", "33"],
    correctAnswer: "33",
    difficulty: 2,
    category: "Pattern Recognition"
  },
  {
    id: 9,
    text: "If you rearrange the letters 'RAPIS', you would have the name of a:",
    options: ["City", "Animal", "River", "Mountain"],
    correctAnswer: "Animal",
    difficulty: 2,
    category: "Verbal Reasoning"
  },
  {
    id: 10,
    text: "Which figure represents the relationship: things that are both square and blue?",
    image: "https://images.pexels.com/photos/2047905/pexels-photo-2047905.jpeg?auto=compress&cs=tinysrgb&w=600",
    options: ["A", "B", "C", "D"],
    correctAnswer: "C",
    difficulty: 2,
    category: "Logical Reasoning"
  },
  {
    id: 11,
    text: "A man is 4 times as old as his son. In 20 years, he will be twice as old as his son. How old is the son now?",
    options: ["10", "15", "20", "25"],
    correctAnswer: "20",
    difficulty: 3,
    category: "Logical Reasoning"
  },
  {
    id: 12,
    text: "Which of these words is most closely related to 'Penumbra'?",
    options: ["Light", "Shadow", "Sun", "Eclipse"],
    correctAnswer: "Shadow",
    difficulty: 3,
    category: "Verbal Reasoning"
  },
  {
    id: 13,
    text: "What number should replace the question mark? 8, 27, 64, 125, ?",
    options: ["196", "216", "256", "343"],
    correctAnswer: "216",
    difficulty: 3,
    category: "Pattern Recognition"
  },
  {
    id: 14,
    text: "If the average of five consecutive integers is 30, what is the largest of these integers?",
    options: ["30", "31", "32", "33"],
    correctAnswer: "32",
    difficulty: 3,
    category: "Logical Reasoning"
  },
  {
    id: 15,
    text: "Which image shows the correct rotation of the given shape?",
    image: "https://images.pexels.com/photos/4344260/pexels-photo-4344260.jpeg?auto=compress&cs=tinysrgb&w=600",
    options: ["Image A", "Image B", "Image C", "Image D"],
    correctAnswer: "Image C",
    difficulty: 3,
    category: "Spatial Reasoning"
  },
  {
    id: 16,
    text: "In a certain code language, NIGHTMARE is written as 14-9-7-8-20-13-1-18-5. How would TERROR be written?",
    options: ["20-5-18-18-15-18", "20-5-12-12-15-18", "20-5-18-19-15-18", "20-5-18-18-18-15"],
    correctAnswer: "20-5-18-18-15-18",
    difficulty: 4,
    category: "Pattern Recognition"
  },
  {
    id: 17,
    text: "Which of these statements must be true if the other two are true? 1. All horrors are fears. 2. Some fears are not nightmares. 3. Some horrors are nightmares.",
    options: ["Statement 1", "Statement 2", "Statement 3", "None must be true"],
    correctAnswer: "None must be true",
    difficulty: 4,
    category: "Logical Reasoning"
  },
  {
    id: 18,
    text: "If 5 people can paint 5 rooms in 5 hours, how many rooms can 10 people paint in 10 hours?",
    options: ["10", "20", "25", "50"],
    correctAnswer: "20",
    difficulty: 4,
    category: "Logical Reasoning"
  },
  {
    id: 19,
    text: "A cube has a red face opposite a green face. The blue face is adjacent to the red face. The yellow face is opposite the blue face. If the orange face is adjacent to the green face, what color is opposite the orange face?",
    options: ["Red", "Blue", "Yellow", "Purple"],
    correctAnswer: "Purple",
    difficulty: 5,
    category: "Spatial Reasoning"
  },
  {
    id: 20,
    text: "In a certain progression, the difference between consecutive terms increases by 2 each time. If the progression starts with 3 and the second term is 7, what is the sixth term?",
    options: ["41", "47", "51", "57"],
    correctAnswer: "51",
    difficulty: 5,
    category: "Pattern Recognition"
  }
];